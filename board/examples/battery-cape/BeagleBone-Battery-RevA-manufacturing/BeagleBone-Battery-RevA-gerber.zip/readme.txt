Date : 02/20/2012 



README for Gerber_BeagleBone_Battery_Cape_20Feb.zip

Files contained in the zip file:

README		      				This file
BeagleBone_Battery_Rev A_lyr1   		Layer 1
BeagleBone_Battery_Rev A_lyr2     		Layer 2
BeagleBone_Battery_Rev A_smc   			Soldermask Layer 1 Side (Component)
BeagleBone_Battery_Rev A_sms    		Soldermask Layer 2 Side (Solder)
BeagleBone_Battery_Rev A_spc    		Solder Paste Layer 1 Side 
BeagleBone_Battery_Rev A_tslk 			Silk Screen Layer 1 side
BeagleBone_Battery_Rev A_bslk 			Silk Screen Layer 2 side
BeagleBone_Battery_Rev A_fab    		Fabrication Drawing (for Ref. ONLY)
BeagleBone_Battery_Rev A_assy   		Assembly Drawing (for Ref. ONLY)
BeagleBone_Battery_Rev A.drl			Drill tape, through
BeagleBone_Battery_Rev A_nc_param.txt 	        Drill tape setup file
BeagleBone_Battery_Rev A_ncdrill.log    	Drill tape composite file (for Reference ONLY)
BeagleBone_Battery_Rev A.ipc   	  		IPC-D-356A netlist (for Checking ONLY)
BeagleBone_Battery_Rev A_art_param.txt  	Artwork Format File (for Ref. ONLY)
BeagleBone_Battery_Rev A_placed_component.xls	Placement file for Assembly (for Ref. Only)
BeagleBone_Battery_Rev A_netlist_allegro.xls 	Allegro Netlist (for Ref. Only)



Notes:	PLEASE REVIEW FAB DRAWING FOR SPECIFIC REQUIREMENTS.

